<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ml-auto mr-auto">
                <div class="card text-center" >
                    <h2 class="mt-4">Elecciones Disponibles</h2>
                    <?php $__currentLoopData = $elecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body">
                            <hr>
                            <br>
                            <h5 class="card-title">"<?php echo e($eleccion->nombre); ?>"</h5>
                            <a class="btn btn-primary"
                               href="<?php echo e(url("resultados/$eleccion->id")); ?>">Revisar Votos</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rodrigo/github/Conteo/laravel-PWA/resources/views/vistas/web/elecciones.blade.php ENDPATH**/ ?>