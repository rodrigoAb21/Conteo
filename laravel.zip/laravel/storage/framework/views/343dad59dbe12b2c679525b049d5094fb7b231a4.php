<?php $__env->startSection('contenido'); ?>
    <div class="row pt-3">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h3 class="pb-2">Recintos
                        <div class="float-right">
                            <a class="btn btn-success" href="<?php echo e(url('admin/recintos/create')); ?>">
                                <i class="fa fa-plus"></i> Nuevo
                            </a>
                        </div>
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered color-table info-table">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>NOMBRE</th>
                                <th>DIRECCION</th>
                                <th>LOCALIDAD</th>
                                <th>PROVINCIA</th>
                                <th>OPCIONES</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $recintos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recinto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($recinto->id); ?></td>
                                    <td><?php echo e($recinto->nombre); ?></td>
                                    <td><?php echo e($recinto->direccion); ?></td>
                                    <td><?php echo e($recinto->localidad->nombre); ?></td>
                                    <td><?php echo e($recinto->localidad->provincia->nombre); ?></td>
                                    <td class="text-right ">
                                        <a href="<?php echo e(url('admin/recintos/'.$recinto->id.'/edit')); ?>">
                                            <button class="btn btn-warning">
                                                <i class="fa fa-pen"></i>
                                            </button>
                                        </a>
                                        <button type="button" class="btn btn-danger" onclick="modalEliminar('<?php echo e($recinto -> nombre); ?>', '<?php echo e(url('admin/recintos/'.$recinto -> id)); ?>')">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($recintos->links('pagination.default')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('vistas.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>

            function modalEliminar(nombre, url) {
                $('#modalEliminarForm').attr("action", url);
                $('#metodo').val("delete");
                $('#modalEliminarTitulo').html("Eliminar Recinto");
                $('#modalEliminarEnunciado').html("Realmente desea eliminar al recinto: " + nombre + "?");
                $('#modalEliminar').modal('show');
            }

        </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rodrigo/Downloads/Compressed/laravel/resources/views/vistas/recintos/index.blade.php ENDPATH**/ ?>