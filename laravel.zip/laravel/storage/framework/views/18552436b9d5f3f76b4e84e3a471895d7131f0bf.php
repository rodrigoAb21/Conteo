<?php $__env->startSection('contenido'); ?>
    <div class="row pt-3">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h3 class="pb-2">Elecciones
                        <div class="float-right">
                            <a class="btn btn-success" href="<?php echo e(url('admin/elecciones/create')); ?>">
                                <i class="fa fa-plus"></i> Nueva
                            </a>
                        </div>
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered color-table info-table">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>NOMBRE</th>
                                <th>FECHA</th>
                                <th>TIPO</th>
                                <th>ESTADO</th>
                                <th>NRO_MESAS</th>
                                <th class="text-right">OPCIONES</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $elecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($eleccion -> id); ?></td>
                                    <td><?php echo e($eleccion -> nombre); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($eleccion -> fecha)->format('d/M/Y')); ?></td>
                                    <td><?php echo e($eleccion -> tipo); ?></td>
                                    <td><?php echo e($eleccion -> estado); ?></td>
                                    <td><?php echo e($eleccion -> mesas); ?></td>
                                    <td class="text-right ">
                                        <a href="<?php echo e(url('admin/elecciones/asignaciones/'.$eleccion->id.'/')); ?>">
                                            <button class="btn btn-success">
                                                <i class="fa fa-angle-double-right"></i>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(url('admin/elecciones/resultados/'.$eleccion->id.'/')); ?>">
                                            <button class="btn btn-info">
                                                <i class="fa fa-chart-pie"></i>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(url('admin/elecciones/'.$eleccion->id.'/edit')); ?>">
                                            <button class="btn btn-warning">
                                                <i class="fa fa-pen"></i>
                                            </button>
                                        </a>
                                        <button type="button" class="btn btn-danger" onclick="modalEliminar('<?php echo e($eleccion -> nombre); ?>', '<?php echo e(url('admin/elecciones/'.$eleccion -> id)); ?>')">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($elecciones->links('pagination.default')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('vistas.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>

            function modalEliminar(nombre, url) {
                $('#modalEliminarForm').attr("action", url);
                $('#metodo').val("delete");
                $('#modalEliminarTitulo').html("Eliminar Eleccion");
                $('#modalEliminarEnunciado').html("Realmente desea eliminar la eleccion: " + nombre + "?");
                $('#modalEliminar').modal('show');
            }

        </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rodrigo/Downloads/Compressed/laravel/resources/views/vistas/elecciones/index.blade.php ENDPATH**/ ?>