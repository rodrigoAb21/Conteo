<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('plantilla/assets/images/favicon.png')); ?>">
    <title>Elecciones</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('plantilla/assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
</head>
<body>
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('plantilla/assets/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo e(asset('plantilla/assets/plugins/bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plantilla/assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('plantilla/assets/plugins/Chart.js/Chart.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/rodrigo/github/Conteo/laravel-PWA/resources/views/layouts/app.blade.php ENDPATH**/ ?>